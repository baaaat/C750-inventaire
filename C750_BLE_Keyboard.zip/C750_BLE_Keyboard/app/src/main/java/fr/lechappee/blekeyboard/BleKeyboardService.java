package fr.lechappee.blekeyboard;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.inputmethodservice.InputMethodService;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.InputConnection;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.nio.charset.StandardCharsets;
import java.util.ArrayDeque;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class BleKeyboardService extends InputMethodService {
    private static final UUID CCCD = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb");
    private static final Pattern EAN = Pattern.compile("\\d{8,14}");
    private static final long FLUSH_DELAY_MS = 90;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ArrayDeque<BluetoothGattDescriptor> descriptorQueue = new ArrayDeque<>();
    private final StringBuilder rx = new StringBuilder();

    private BluetoothAdapter adapter;
    private BluetoothGatt gatt;
    private TextView statusView;
    private boolean connecting;
    private String lastCommitted = "";

    private final Runnable flushRunnable = this::flushBarcodeBuffer;

    @Override public void onCreate() {
        super.onCreate();
        BluetoothManager manager = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
        adapter = manager == null ? null : manager.getAdapter();
    }

    @Override public View onCreateInputView() {
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        int p = dp(8);
        bar.setPadding(p, p, p, p);
        bar.setBackgroundColor(Color.rgb(245, 245, 245));

        statusView = new TextView(this);
        statusView.setText("C750 : prêt");
        statusView.setTextColor(Color.DKGRAY);
        statusView.setTextSize(15);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(48), 1f);
        statusView.setGravity(Gravity.CENTER_VERTICAL);
        bar.addView(statusView, lp);

        Button reconnect = new Button(this);
        reconnect.setAllCaps(false);
        reconnect.setText("Reconnecter");
        reconnect.setOnClickListener(v -> reconnect());
        bar.addView(reconnect);

        Button next = new Button(this);
        next.setAllCaps(false);
        next.setText("Autre clavier");
        next.setOnClickListener(v -> {
            if (Build.VERSION.SDK_INT >= 16) switchToNextInputMethod(false);
        });
        bar.addView(next);
        return bar;
    }

    @Override public void onStartInputView(android.view.inputmethod.EditorInfo info, boolean restarting) {
        super.onStartInputView(info, restarting);
        ensureConnected();
    }

    @Override public void onDestroy() {
        disconnect();
        super.onDestroy();
    }

    private boolean hasPermissions() {
        if (Build.VERSION.SDK_INT >= 31) {
            return checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
                    && checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED;
        }
        return true;
    }

    private void ensureConnected() {
        if (!hasPermissions()) {
            setStatus("Permission Bluetooth manquante — ouvre l'appli");
            return;
        }
        if (adapter == null || !adapter.isEnabled()) {
            setStatus("Bluetooth désactivé");
            return;
        }
        String mac = getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE).getString(MainActivity.KEY_MAC, "");
        if (mac.isEmpty()) {
            setStatus("Aucun C750 choisi — ouvre l'appli");
            return;
        }
        if (gatt != null || connecting) return;
        try {
            BluetoothDevice device = adapter.getRemoteDevice(mac);
            connecting = true;
            setStatus("C750 : connexion…");
            gatt = device.connectGatt(this, true, gattCb, BluetoothDevice.TRANSPORT_LE);
        } catch (Exception e) {
            connecting = false;
            setStatus("Connexion impossible");
        }
    }

    private void reconnect() {
        disconnect();
        handler.postDelayed(this::ensureConnected, 250);
    }

    private void disconnect() {
        connecting = false;
        descriptorQueue.clear();
        handler.removeCallbacks(flushRunnable);
        if (gatt != null) {
            try { gatt.disconnect(); } catch (Exception ignored) {}
            try { gatt.close(); } catch (Exception ignored) {}
            gatt = null;
        }
    }

    private final BluetoothGattCallback gattCb = new BluetoothGattCallback() {
        @Override public void onConnectionStateChange(BluetoothGatt g, int status, int newState) {
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                connecting = false;
                setStatus("C750 connecté — préparation…");
                try { g.discoverServices(); } catch (SecurityException e) { setStatus("Permission Bluetooth manquante"); }
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                connecting = false;
                if (gatt == g) gatt = null;
                try { g.close(); } catch (Exception ignored) {}
                setStatus("C750 déconnecté — reconnexion…");
                handler.postDelayed(BleKeyboardService.this::ensureConnected, 1200);
            }
        }

        @Override public void onServicesDiscovered(BluetoothGatt g, int status) {
            if (status != BluetoothGatt.GATT_SUCCESS) {
                setStatus("C750 connecté, services indisponibles");
                return;
            }
            descriptorQueue.clear();
            int subscribed = 0;
            try {
                for (BluetoothGattService service : g.getServices()) {
                    for (BluetoothGattCharacteristic ch : service.getCharacteristics()) {
                        int props = ch.getProperties();
                        boolean notify = (props & BluetoothGattCharacteristic.PROPERTY_NOTIFY) != 0;
                        boolean indicate = (props & BluetoothGattCharacteristic.PROPERTY_INDICATE) != 0;
                        if (!notify && !indicate) continue;
                        if (!g.setCharacteristicNotification(ch, true)) continue;
                        BluetoothGattDescriptor cccd = ch.getDescriptor(CCCD);
                        if (cccd != null) {
                            byte[] value = indicate ? BluetoothGattDescriptor.ENABLE_INDICATION_VALUE
                                    : BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE;
                            cccd.setValue(value);
                            descriptorQueue.add(cccd);
                            subscribed++;
                        }
                    }
                }
            } catch (SecurityException e) {
                setStatus("Permission Bluetooth manquante");
                return;
            }
            if (subscribed == 0) {
                setStatus("C750 connecté mais canal de données introuvable");
            } else {
                writeNextDescriptor(g);
            }
        }

        @Override public void onDescriptorWrite(BluetoothGatt g, BluetoothGattDescriptor descriptor, int status) {
            writeNextDescriptor(g);
        }

        @Override public void onCharacteristicChanged(BluetoothGatt g, BluetoothGattCharacteristic characteristic) {
            onBleBytes(characteristic.getValue());
        }

        @Override public void onCharacteristicChanged(BluetoothGatt g, BluetoothGattCharacteristic characteristic, byte[] value) {
            onBleBytes(value);
        }
    };

    private void writeNextDescriptor(BluetoothGatt g) {
        BluetoothGattDescriptor d = descriptorQueue.poll();
        if (d == null) {
            setStatus("C750 connecté — prêt à scanner");
            return;
        }
        try {
            if (Build.VERSION.SDK_INT >= 33) {
                g.writeDescriptor(d, d.getValue());
            } else {
                g.writeDescriptor(d);
            }
        } catch (SecurityException e) {
            setStatus("Permission Bluetooth manquante");
        }
    }

    private void onBleBytes(byte[] bytes) {
        if (bytes == null || bytes.length == 0) return;
        String s = new String(bytes, StandardCharsets.UTF_8);
        synchronized (rx) {
            for (int i = 0; i < s.length(); i++) {
                char c = s.charAt(i);
                if (Character.isDigit(c)) rx.append(c);
                else if (c == '\r' || c == '\n') {
                    handler.removeCallbacks(flushRunnable);
                    handler.post(this::flushBarcodeBuffer);
                }
            }
        }
        handler.removeCallbacks(flushRunnable);
        handler.postDelayed(flushRunnable, FLUSH_DELAY_MS);
    }

    private void flushBarcodeBuffer() {
        final String raw;
        synchronized (rx) {
            raw = rx.toString();
            rx.setLength(0);
        }
        if (raw.isEmpty()) return;
        Matcher m = EAN.matcher(raw);
        String code = null;
        while (m.find()) code = m.group();
        if (code == null) return;

        final String result = code;
        handler.post(() -> commitScan(result));
    }

    private void commitScan(String code) {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) {
            setStatus("Scan reçu mais aucun champ actif");
            return;
        }
        if (code.equals(lastCommitted)) {
            // Les scans consécutifs du même article doivent rester possibles.
            lastCommitted = "";
        }
        ic.commitText(code, 1);
        ic.sendKeyEvent(new KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_ENTER));
        ic.sendKeyEvent(new KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_ENTER));
        lastCommitted = code;
        setStatus("C750 : " + code);
    }

    private void setStatus(String text) {
        handler.post(() -> {
            if (statusView != null) statusView.setText(text);
        });
    }

    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }
}
