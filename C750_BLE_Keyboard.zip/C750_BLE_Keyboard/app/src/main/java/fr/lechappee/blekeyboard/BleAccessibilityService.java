package fr.lechappee.blekeyboard;

import android.Manifest;
import android.accessibilityservice.AccessibilityService;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import java.nio.charset.StandardCharsets;
import java.util.ArrayDeque;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Service principal de la V2.
 *
 * Le clavier Samsung/Gboard reste le clavier Android actif. Ce service d'accessibilite
 * maintient la connexion BLE avec le Netum C750 et injecte le code dans le champ texte
 * actuellement actif (Chrome/Shifter ou autre application), puis demande l'action Entree.
 */
public class BleAccessibilityService extends AccessibilityService {
    private static final UUID CCCD = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb");
    private static final Pattern EAN = Pattern.compile("\\d{8,14}");
    private static final long FLUSH_DELAY_MS = 90;
    private static final long RECONNECT_DELAY_MS = 1200;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ArrayDeque<BluetoothGattDescriptor> descriptorQueue = new ArrayDeque<>();
    private final StringBuilder rx = new StringBuilder();

    private BluetoothAdapter adapter;
    private BluetoothGatt gatt;
    private boolean connecting;
    private boolean ready;

    private final Runnable flushRunnable = this::flushBarcodeBuffer;

    @Override
    public void onServiceConnected() {
        super.onServiceConnected();
        BluetoothManager manager = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
        adapter = manager == null ? null : manager.getAdapter();
        saveStatus("Service actif — connexion au C750…");
        ensureConnected();
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        // Un changement de fenetre/focus est aussi une bonne occasion de retenter la connexion.
        if (gatt == null && !connecting) ensureConnected();
    }

    @Override
    public void onInterrupt() {
        saveStatus("Service d'accessibilité interrompu");
    }

    @Override
    public boolean onUnbind(android.content.Intent intent) {
        disconnect();
        return super.onUnbind(intent);
    }

    @Override
    public void onDestroy() {
        disconnect();
        super.onDestroy();
    }

    private boolean hasPermissions() {
        if (Build.VERSION.SDK_INT >= 31) {
            return checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
                    && checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED;
        }
        return true;
    }

    private void ensureConnected() {
        if (!hasPermissions()) {
            saveStatus("Permission Bluetooth manquante — ouvre l'appli");
            return;
        }
        if (adapter == null || !adapter.isEnabled()) {
            saveStatus("Bluetooth désactivé");
            return;
        }
        String mac = getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE)
                .getString(MainActivity.KEY_MAC, "");
        if (mac.isEmpty()) {
            saveStatus("Aucun C750 choisi — ouvre l'appli");
            return;
        }
        if (gatt != null || connecting) return;

        try {
            BluetoothDevice device = adapter.getRemoteDevice(mac);
            connecting = true;
            ready = false;
            saveStatus("C750 : connexion…");
            gatt = device.connectGatt(this, true, gattCb, BluetoothDevice.TRANSPORT_LE);
        } catch (Exception e) {
            connecting = false;
            saveStatus("Connexion C750 impossible");
            handler.postDelayed(this::ensureConnected, RECONNECT_DELAY_MS);
        }
    }

    private void disconnect() {
        connecting = false;
        ready = false;
        descriptorQueue.clear();
        handler.removeCallbacks(flushRunnable);
        if (gatt != null) {
            try { gatt.disconnect(); } catch (Exception ignored) {}
            try { gatt.close(); } catch (Exception ignored) {}
            gatt = null;
        }
    }

    private final BluetoothGattCallback gattCb = new BluetoothGattCallback() {
        @Override
        public void onConnectionStateChange(BluetoothGatt g, int status, int newState) {
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                connecting = false;
                saveStatus("C750 connecté — préparation…");
                try {
                    g.discoverServices();
                } catch (SecurityException e) {
                    saveStatus("Permission Bluetooth manquante");
                }
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                connecting = false;
                ready = false;
                if (gatt == g) gatt = null;
                try { g.close(); } catch (Exception ignored) {}
                saveStatus("C750 déconnecté — reconnexion…");
                handler.postDelayed(BleAccessibilityService.this::ensureConnected, RECONNECT_DELAY_MS);
            }
        }

        @Override
        public void onServicesDiscovered(BluetoothGatt g, int status) {
            if (status != BluetoothGatt.GATT_SUCCESS) {
                saveStatus("C750 connecté, services indisponibles");
                return;
            }

            descriptorQueue.clear();
            int subscribed = 0;
            try {
                for (BluetoothGattService service : g.getServices()) {
                    for (BluetoothGattCharacteristic ch : service.getCharacteristics()) {
                        int props = ch.getProperties();
                        boolean notify = (props & BluetoothGattCharacteristic.PROPERTY_NOTIFY) != 0;
                        boolean indicate = (props & BluetoothGattCharacteristic.PROPERTY_INDICATE) != 0;
                        if (!notify && !indicate) continue;
                        if (!g.setCharacteristicNotification(ch, true)) continue;

                        BluetoothGattDescriptor cccd = ch.getDescriptor(CCCD);
                        if (cccd != null) {
                            cccd.setValue(indicate
                                    ? BluetoothGattDescriptor.ENABLE_INDICATION_VALUE
                                    : BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
                            descriptorQueue.add(cccd);
                            subscribed++;
                        }
                    }
                }
            } catch (SecurityException e) {
                saveStatus("Permission Bluetooth manquante");
                return;
            }

            if (subscribed == 0) {
                saveStatus("C750 connecté mais canal de données introuvable");
            } else {
                writeNextDescriptor(g);
            }
        }

        @Override
        public void onDescriptorWrite(BluetoothGatt g, BluetoothGattDescriptor descriptor, int status) {
            writeNextDescriptor(g);
        }

        @Override
        public void onCharacteristicChanged(BluetoothGatt g, BluetoothGattCharacteristic characteristic) {
            onBleBytes(characteristic.getValue());
        }

        @Override
        public void onCharacteristicChanged(BluetoothGatt g, BluetoothGattCharacteristic characteristic, byte[] value) {
            onBleBytes(value);
        }
    };

    private void writeNextDescriptor(BluetoothGatt g) {
        BluetoothGattDescriptor d = descriptorQueue.poll();
        if (d == null) {
            ready = true;
            saveStatus("C750 connecté — prêt à scanner");
            return;
        }
        try {
            if (Build.VERSION.SDK_INT >= 33) {
                g.writeDescriptor(d, d.getValue());
            } else {
                g.writeDescriptor(d);
            }
        } catch (SecurityException e) {
            saveStatus("Permission Bluetooth manquante");
        }
    }

    private void onBleBytes(byte[] bytes) {
        if (bytes == null || bytes.length == 0) return;
        String s = new String(bytes, StandardCharsets.UTF_8);
        synchronized (rx) {
            for (int i = 0; i < s.length(); i++) {
                char c = s.charAt(i);
                if (Character.isDigit(c)) {
                    rx.append(c);
                } else if (c == '\r' || c == '\n') {
                    handler.removeCallbacks(flushRunnable);
                    handler.post(this::flushBarcodeBuffer);
                }
            }
        }
        handler.removeCallbacks(flushRunnable);
        handler.postDelayed(flushRunnable, FLUSH_DELAY_MS);
    }

    private void flushBarcodeBuffer() {
        final String raw;
        synchronized (rx) {
            raw = rx.toString();
            rx.setLength(0);
        }
        if (raw.isEmpty()) return;

        Matcher m = EAN.matcher(raw);
        String code = null;
        while (m.find()) code = m.group();
        if (code == null) return;
        final String result = code;
        handler.post(() -> injectScan(result));
    }

    private void injectScan(String code) {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) {
            saveStatus("Scan " + code + " reçu — aucune fenêtre active");
            return;
        }

        AccessibilityNodeInfo field = findEditableFocusedNode(root);
        if (field == null) {
            saveStatus("Scan " + code + " reçu — touche d'abord un champ");
            return;
        }

        CharSequence oldSeq = field.getText();
        String oldText = oldSeq == null ? "" : oldSeq.toString();
        int start = field.getTextSelectionStart();
        int end = field.getTextSelectionEnd();
        if (start < 0 || end < 0 || start > oldText.length() || end > oldText.length()) {
            start = oldText.length();
            end = oldText.length();
        }
        if (start > end) {
            int t = start; start = end; end = t;
        }

        String newText = oldText.substring(0, start) + code + oldText.substring(end);
        int cursor = start + code.length();

        Bundle set = new Bundle();
        set.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, newText);
        boolean inserted = field.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, set);
        if (!inserted) {
            saveStatus("Scan " + code + " reçu — ce champ refuse l'insertion");
            field.recycle();
            root.recycle();
            return;
        }

        Bundle selection = new Bundle();
        selection.putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_START_INT, cursor);
        selection.putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_END_INT, cursor);
        field.performAction(AccessibilityNodeInfo.ACTION_SET_SELECTION, selection);

        // Android 11+ expose directement l'action IME Enter aux services d'accessibilite.
        // Sur les versions plus anciennes, le texte est tout de meme insere; Shifter peut
        // alors reagir a l'evenement input/change selon son implementation.
        boolean enterSent = false;
        if (Build.VERSION.SDK_INT >= 30) {
            enterSent = field.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.getId());
        }

        getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE).edit()
                .putString(MainActivity.KEY_LAST_SCAN, code)
                .putLong(MainActivity.KEY_LAST_SCAN_AT, System.currentTimeMillis())
                .apply();
        saveStatus(enterSent ? "C750 : " + code + " + Entrée" : "C750 : " + code + " inséré");

        field.recycle();
        root.recycle();
    }

    private AccessibilityNodeInfo findEditableFocusedNode(AccessibilityNodeInfo root) {
        AccessibilityNodeInfo inputFocus = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT);
        if (isUsableEditable(inputFocus)) return AccessibilityNodeInfo.obtain(inputFocus);

        AccessibilityNodeInfo accessibilityFocus = root.findFocus(AccessibilityNodeInfo.FOCUS_ACCESSIBILITY);
        if (isUsableEditable(accessibilityFocus)) return AccessibilityNodeInfo.obtain(accessibilityFocus);

        return findEditableFocusedNodeRecursive(root);
    }

    private AccessibilityNodeInfo findEditableFocusedNodeRecursive(AccessibilityNodeInfo node) {
        if (node == null) return null;
        if (isUsableEditable(node) && (node.isFocused() || node.isAccessibilityFocused())) {
            return AccessibilityNodeInfo.obtain(node);
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child == null) continue;
            AccessibilityNodeInfo result = findEditableFocusedNodeRecursive(child);
            child.recycle();
            if (result != null) return result;
        }
        return null;
    }

    private boolean isUsableEditable(AccessibilityNodeInfo node) {
        if (node == null || !node.isEnabled()) return false;
        return node.isEditable()
                || node.getActionList().contains(AccessibilityNodeInfo.AccessibilityAction.ACTION_SET_TEXT);
    }

    private void saveStatus(String text) {
        SharedPreferences.Editor e = getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE).edit();
        e.putString(MainActivity.KEY_SERVICE_STATUS, text);
        e.putBoolean(MainActivity.KEY_SERVICE_READY, ready);
        e.apply();
    }
}
