package fr.lechappee.blekeyboard;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanResult;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

public class MainActivity extends Activity {
    static final String PREFS = "ble_keyboard";
    static final String KEY_MAC = "scanner_mac";
    static final String KEY_NAME = "scanner_name";
    private static final int REQ_BT = 11;

    private BluetoothAdapter adapter;
    private BluetoothLeScanner scanner;
    private boolean scanning;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final LinkedHashMap<String, ScanResult> found = new LinkedHashMap<>();
    private LinearLayout deviceList;
    private TextView status;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        BluetoothManager manager = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
        adapter = manager == null ? null : manager.getAdapter();
        buildUi();
        refreshStatus();
    }

    private void buildUi() {
        int pad = dp(18);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, pad, pad, pad);

        TextView title = new TextView(this);
        title.setText("C750 BLE → clavier Android");
        title.setTextSize(24);
        title.setTextColor(Color.BLACK);
        root.addView(title);

        TextView help = new TextView(this);
        help.setText("1. Choisis le scanner C750 ci-dessous.\n2. Active « C750 BLE Keyboard » dans les claviers Android.\n3. Sélectionne ce clavier dans Chrome/Shifter.\n4. Le scan sera saisi dans le champ actif puis Entrée sera envoyé.");
        help.setTextSize(16);
        help.setPadding(0, dp(12), 0, dp(12));
        root.addView(help);

        status = new TextView(this);
        status.setTextSize(16);
        status.setPadding(0, 0, 0, dp(12));
        root.addView(status);

        Button enableIme = new Button(this);
        enableIme.setText("Activer le clavier C750");
        enableIme.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)));
        root.addView(enableIme);

        Button chooseIme = new Button(this);
        chooseIme.setText("Choisir le clavier actif");
        chooseIme.setOnClickListener(v -> {
            android.view.inputmethod.InputMethodManager imm =
                    (android.view.inputmethod.InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
            if (imm != null) imm.showInputMethodPicker();
        });
        root.addView(chooseIme);

        Button scan = new Button(this);
        scan.setText("Rechercher / choisir le C750");
        scan.setOnClickListener(v -> ensurePermissionsAndScan());
        root.addView(scan);

        deviceList = new LinearLayout(this);
        deviceList.setOrientation(LinearLayout.VERTICAL);
        deviceList.setPadding(0, dp(10), 0, 0);
        root.addView(deviceList);

        setContentView(root);
    }

    private void refreshStatus() {
        SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
        String mac = p.getString(KEY_MAC, "");
        String name = p.getString(KEY_NAME, "");
        status.setText(mac.isEmpty() ? "Scanner : aucun scanner mémorisé" : "Scanner mémorisé : " + name + "  " + mac);
    }

    private boolean hasBtPermissions() {
        if (Build.VERSION.SDK_INT >= 31) {
            return checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED
                    && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED;
        }
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private void ensurePermissionsAndScan() {
        if (adapter == null) {
            toast("Bluetooth indisponible");
            return;
        }
        if (!hasBtPermissions()) {
            if (Build.VERSION.SDK_INT >= 31) {
                requestPermissions(new String[]{Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT}, REQ_BT);
            } else {
                requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQ_BT);
            }
            return;
        }
        startScan();
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == REQ_BT && hasBtPermissions()) startScan();
    }

    private void startScan() {
        if (!adapter.isEnabled()) {
            toast("Active le Bluetooth puis relance la recherche");
            startActivity(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS));
            return;
        }
        scanner = adapter.getBluetoothLeScanner();
        if (scanner == null) {
            toast("Scanner BLE indisponible");
            return;
        }
        found.clear();
        deviceList.removeAllViews();
        status.setText("Recherche BLE en cours…");
        try {
            scanning = true;
            scanner.startScan(scanCb);
            handler.postDelayed(this::stopScan, 9000);
        } catch (SecurityException e) {
            toast("Permission Bluetooth manquante");
        }
    }

    private void stopScan() {
        if (!scanning || scanner == null) return;
        scanning = false;
        try { scanner.stopScan(scanCb); } catch (SecurityException ignored) {}
        if (found.isEmpty()) status.setText("Aucun appareil trouvé. Vérifie que le C750 est en mode BLE.");
        else status.setText("Choisis le C750 dans la liste :");
    }

    private final ScanCallback scanCb = new ScanCallback() {
        @Override public void onScanResult(int callbackType, ScanResult result) {
            BluetoothDevice d = result.getDevice();
            String name = safeName(d);
            String low = name.toLowerCase(Locale.ROOT);
            if (!(low.contains("c750") || low.contains("netum") || low.contains("barcode") || low.contains("scanner"))) return;
            String address;
            try { address = d.getAddress(); } catch (SecurityException e) { return; }
            if (found.containsKey(address)) return;
            found.put(address, result);
            addDeviceButton(result);
        }
    };

    private String safeName(BluetoothDevice d) {
        try {
            String n = d.getName();
            return n == null || n.trim().isEmpty() ? "Appareil BLE" : n.trim();
        } catch (SecurityException e) {
            return "Appareil BLE";
        }
    }

    private void addDeviceButton(ScanResult result) {
        BluetoothDevice d = result.getDevice();
        String name = safeName(d);
        String address;
        try { address = d.getAddress(); } catch (SecurityException e) { return; }
        Button b = new Button(this);
        b.setAllCaps(false);
        b.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        b.setText(name + "\n" + address + "   (" + result.getRssi() + " dBm)");
        b.setOnClickListener(v -> {
            getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                    .putString(KEY_MAC, address)
                    .putString(KEY_NAME, name)
                    .apply();
            stopScan();
            refreshStatus();
            toast("C750 mémorisé. Active maintenant le clavier C750.");
        });
        deviceList.addView(b);
    }

    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }
    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }
}
