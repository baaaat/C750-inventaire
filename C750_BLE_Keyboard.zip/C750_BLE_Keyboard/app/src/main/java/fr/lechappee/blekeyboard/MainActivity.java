package fr.lechappee.blekeyboard;

import android.Manifest;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanResult;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.accessibility.AccessibilityManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    static final String PREFS = "ble_keyboard";
    static final String KEY_MAC = "scanner_mac";
    static final String KEY_NAME = "scanner_name";
    static final String KEY_SERVICE_STATUS = "service_status";
    static final String KEY_SERVICE_READY = "service_ready";
    static final String KEY_LAST_SCAN = "last_scan";
    static final String KEY_LAST_SCAN_AT = "last_scan_at";

    private static final int REQ_BT = 11;

    private BluetoothAdapter adapter;
    private BluetoothLeScanner scanner;
    private boolean scanning;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final LinkedHashMap<String, ScanResult> found = new LinkedHashMap<>();

    private LinearLayout deviceList;
    private TextView status;
    private TextView serviceStatus;

    private final Runnable refreshRunnable = new Runnable() {
        @Override public void run() {
            refreshStatus();
            handler.postDelayed(this, 1000);
        }
    };

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        BluetoothManager manager = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
        adapter = manager == null ? null : manager.getAdapter();
        buildUi();
        refreshStatus();
    }

    @Override protected void onResume() {
        super.onResume();
        handler.removeCallbacks(refreshRunnable);
        handler.post(refreshRunnable);
    }

    @Override protected void onPause() {
        handler.removeCallbacks(refreshRunnable);
        super.onPause();
    }

    private void buildUi() {
        int pad = dp(18);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, pad, pad, pad);

        TextView title = new TextView(this);
        title.setText("C750 Scanner automatique");
        title.setTextSize(24);
        title.setTextColor(Color.BLACK);
        root.addView(title);

        TextView help = new TextView(this);
        help.setText("Le clavier Samsung/Gboard reste actif en permanence.\n\n" +
                "1. Choisis une fois le scanner C750.\n" +
                "2. Active le service « C750 Scanner automatique ».\n" +
                "3. Dans Shifter/Chrome, touche simplement le champ à remplir.\n" +
                "4. Scanne : le code est inséré puis Entrée est envoyée automatiquement.\n\n" +
                "Tu n'as plus besoin de changer de clavier.");
        help.setTextSize(16);
        help.setPadding(0, dp(12), 0, dp(12));
        root.addView(help);

        status = new TextView(this);
        status.setTextSize(16);
        status.setPadding(0, 0, 0, dp(8));
        root.addView(status);

        serviceStatus = new TextView(this);
        serviceStatus.setTextSize(16);
        serviceStatus.setPadding(0, 0, 0, dp(14));
        root.addView(serviceStatus);

        Button accessibility = new Button(this);
        accessibility.setAllCaps(false);
        accessibility.setText("Activer le scanner automatique");
        accessibility.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        root.addView(accessibility);

        Button scan = new Button(this);
        scan.setAllCaps(false);
        scan.setText("Rechercher / choisir le C750");
        scan.setOnClickListener(v -> ensurePermissionsAndScan());
        root.addView(scan);

        Button bluetooth = new Button(this);
        bluetooth.setAllCaps(false);
        bluetooth.setText("Réglages Bluetooth");
        bluetooth.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS)));
        root.addView(bluetooth);

        deviceList = new LinearLayout(this);
        deviceList.setOrientation(LinearLayout.VERTICAL);
        deviceList.setPadding(0, dp(10), 0, 0);
        root.addView(deviceList);

        setContentView(root);
    }

    private void refreshStatus() {
        SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
        String mac = p.getString(KEY_MAC, "");
        String name = p.getString(KEY_NAME, "");
        status.setText(mac.isEmpty()
                ? "Scanner : aucun scanner mémorisé"
                : "Scanner mémorisé : " + name + "  " + mac);

        boolean enabled = isAccessibilityServiceEnabled();
        String live = p.getString(KEY_SERVICE_STATUS, "");
        String last = p.getString(KEY_LAST_SCAN, "");
        String text = enabled ? "Service automatique : ACTIVÉ" : "Service automatique : DÉSACTIVÉ";
        if (!live.isEmpty()) text += "\n" + live;
        if (!last.isEmpty()) text += "\nDernier scan : " + last;
        serviceStatus.setText(text);
        serviceStatus.setTextColor(enabled ? Color.rgb(0, 110, 70) : Color.rgb(180, 50, 40));
    }

    private boolean isAccessibilityServiceEnabled() {
        AccessibilityManager am = (AccessibilityManager) getSystemService(ACCESSIBILITY_SERVICE);
        if (am == null) return false;
        List<AccessibilityServiceInfo> enabled = am.getEnabledAccessibilityServiceList(
                AccessibilityServiceInfo.FEEDBACK_ALL_MASK);
        for (AccessibilityServiceInfo info : enabled) {
            if (info.getResolveInfo() == null || info.getResolveInfo().serviceInfo == null) continue;
            android.content.pm.ServiceInfo si = info.getResolveInfo().serviceInfo;
            if (getPackageName().equals(si.packageName)
                    && BleAccessibilityService.class.getName().equals(si.name)) return true;
        }
        return false;
    }

    private boolean hasBtPermissions() {
        if (Build.VERSION.SDK_INT >= 31) {
            return checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED
                    && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED;
        }
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private void ensurePermissionsAndScan() {
        if (adapter == null) {
            toast("Bluetooth indisponible");
            return;
        }
        if (!hasBtPermissions()) {
            if (Build.VERSION.SDK_INT >= 31) {
                requestPermissions(new String[]{Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT}, REQ_BT);
            } else {
                requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQ_BT);
            }
            return;
        }
        startScan();
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == REQ_BT && hasBtPermissions()) startScan();
    }

    private void startScan() {
        if (!adapter.isEnabled()) {
            toast("Active le Bluetooth puis relance la recherche");
            startActivity(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS));
            return;
        }
        scanner = adapter.getBluetoothLeScanner();
        if (scanner == null) {
            toast("Scanner BLE indisponible");
            return;
        }
        found.clear();
        deviceList.removeAllViews();
        status.setText("Recherche BLE en cours…");
        try {
            scanning = true;
            scanner.startScan(scanCb);
            handler.postDelayed(this::stopScan, 9000);
        } catch (SecurityException e) {
            toast("Permission Bluetooth manquante");
        }
    }

    private void stopScan() {
        if (!scanning || scanner == null) return;
        scanning = false;
        try { scanner.stopScan(scanCb); } catch (SecurityException ignored) {}
        if (found.isEmpty()) status.setText("Aucun appareil trouvé. Vérifie que le C750 est en mode BLE.");
        else status.setText("Choisis le C750 dans la liste :");
    }

    private final ScanCallback scanCb = new ScanCallback() {
        @Override public void onScanResult(int callbackType, ScanResult result) {
            BluetoothDevice d = result.getDevice();
            String name = safeName(d);
            String low = name.toLowerCase(Locale.ROOT);
            if (!(low.contains("c750") || low.contains("netum") || low.contains("barcode") || low.contains("scanner"))) return;
            String address;
            try { address = d.getAddress(); } catch (SecurityException e) { return; }
            if (found.containsKey(address)) return;
            found.put(address, result);
            addDeviceButton(result);
        }
    };

    private String safeName(BluetoothDevice d) {
        try {
            String n = d.getName();
            return n == null || n.trim().isEmpty() ? "Appareil BLE" : n.trim();
        } catch (SecurityException e) {
            return "Appareil BLE";
        }
    }

    private void addDeviceButton(ScanResult result) {
        BluetoothDevice d = result.getDevice();
        String name = safeName(d);
        String address;
        try { address = d.getAddress(); } catch (SecurityException e) { return; }
        Button b = new Button(this);
        b.setAllCaps(false);
        b.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        b.setText(name + "\n" + address + "   (" + result.getRssi() + " dBm)");
        b.setOnClickListener(v -> {
            getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                    .putString(KEY_MAC, address)
                    .putString(KEY_NAME, name)
                    .putString(KEY_SERVICE_STATUS, "Scanner mémorisé — active le service automatique")
                    .apply();
            stopScan();
            refreshStatus();
            toast("C750 mémorisé. Active maintenant le scanner automatique.");
        });
        deviceList.addView(b);
    }

    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }
    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }
}
