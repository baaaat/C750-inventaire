C750 Scanner automatique — V2
==============================

Cette version n'oblige plus à choisir « C750 BLE Keyboard » comme clavier Android.
Samsung Keyboard / Gboard peut rester le clavier actif en permanence.

Installation :
1. Installer l'APK et autoriser Bluetooth.
2. Ouvrir « C750 Scanner » et choisir le Netum C750.
3. Appuyer sur « Activer le scanner automatique ».
4. Dans les réglages d'accessibilité Android, activer « C750 Scanner automatique ».
5. Ouvrir Chrome/Shifter, toucher le champ de scan et scanner.

Le service reçoit le code en BLE, l'insère dans le champ texte actif et, sur Android 11+
quand le champ l'accepte, déclenche l'action Entrée automatiquement.

L'ancien clavier IME « C750 BLE Keyboard (secours) » est conservé uniquement en solution
de secours. Il n'est plus nécessaire pour l'utilisation normale.
