C750 BLE Keyboard
=================

But : utiliser le Netum C750 en BLE dans Chrome/Shifter comme s'il s'agissait d'un clavier.

Principe : l'application fournit un clavier Android (IME). Le service se connecte directement au C750 en BLE, reçoit le code-barres, l'insère dans le champ actif puis envoie Entrée.

Installation :
1. Compiler et installer l'APK.
2. Ouvrir l'application et choisir le C750.
3. Appuyer sur « Activer le clavier C750 » et autoriser « C750 BLE Keyboard ».
4. Appuyer sur « Choisir le clavier actif », sélectionner « C750 BLE Keyboard ».
5. Ouvrir Chrome / Shifter et placer le curseur dans le champ de scan.
6. Scanner. Le code est saisi suivi d'Entrée.

Le bandeau du clavier affiche l'état de connexion et contient un bouton Reconnecter ainsi qu'un bouton Autre clavier.
